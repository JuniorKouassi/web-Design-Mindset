# Handoff: Animated Background — Web Design Mindset

## Overview
This handoff delivers an **animated background** designed to be used as the global website background for the **WEB DESIGN MINDSET** site (web marketing agency, green & black brand). The animation evokes growth, energy and connection — appropriate visual language for a marketing-focused site — while remaining subtle enough to keep foreground content readable.

The visual is a **canvas-based "aurora"**: soft green light bands flowing slowly across a near-black background, accented by a faint tech grid with pulsing nodes, drifting particles (slight upward bias = "growth" metaphor), a radial vignette, and a low-opacity film grain. It is **purely decorative** — no user interaction, no input, no accessibility tab stops.

## About the Design Files
The file in this bundle (`background.html`) is a **design reference created in HTML/Canvas** — a working prototype showing the intended look and motion behavior, not production code to drop in verbatim.

The task is to **integrate this animation into the existing WEB DESIGN MINDSET codebase** as the site-wide background, following the project's established framework, file structure, and naming conventions. The canvas drawing logic can be lifted essentially as-is (it is plain vanilla JS with no dependencies); the markup wrapper should be adapted to fit the site's layout system.

## Fidelity
**High-fidelity.** Colors, motion parameters (speed, intensity, particle count, grain) and visual treatment are final and have been approved by the user. Recreate the motion and palette faithfully.

## Integration goal
Replace the current site background with this animation **site-wide**, behind all existing page content. Key requirements:

1. The animation must sit **behind** all foreground content (z-index below site UI).
2. It must **fill the viewport** of the site (the 16:9 letterbox in the prototype is only because this was authored as a standalone design artifact — **drop the letterbox for production** and let the canvas fill 100vw / 100vh, fixed to the viewport).
3. It must **not block pointer events** on content above it (`pointer-events: none` on the wrapper).
4. It should run during scroll without re-painting layout (use `position: fixed; inset: 0; z-index: -1;` or equivalent).
5. Respect `prefers-reduced-motion` — when the user has reduced-motion enabled, render a **single static frame** (call the draw functions once and don't schedule `requestAnimationFrame`).

## Visual specification

### Frame / placement
- Fixed full-viewport canvas, behind everything else.
- DPR-aware: `canvas.width = cssWidth * devicePixelRatio` (capped at 2× for perf), then `ctx.setTransform(DPR, 0, 0, DPR, 0, 0)`.
- Resize on `window.resize`.

### Background fill
- Base color: `#050807` (a green-leaning near-black).
- Each frame begins with a **fade overlay**, not a full clear: `ctx.fillStyle = 'rgba(5, 8, 7, 0.12)'; ctx.fillRect(0,0,W,H)` — this is what creates the motion-blur trail. **Do not replace with `clearRect`** — you will lose the look.

### Layer order (each frame, back to front)
1. Fade overlay (above).
2. Tech grid + pulsing nodes.
3. Aurora bands (4 filled bands + 2 bright filament lines on top).
4. Drifting particles.
5. Radial vignette.
6. Film grain.

### Aurora bands
- 4 filled bands, each a smooth horizontal curve filled down to the bottom edge.
- Each band's y is computed from two summed sine waves; phase advances with time × `0.00015 × speed`.
- Fill uses a vertical linear gradient in OKLCH: `oklch(0.72 0.18 145 / a)` → `oklch(0.55 0.15 145 / a*0.6)` → `oklch(0.2 0.04 145 / 0)`, where `a = 0.06 × intensity × (1 - bandIndex × 0.15)`.
- On top, 2 thin stroked filament lines at `oklch(0.85 0.2 145 / 0.25 × intensity)`, lineWidth 1.1.

### Tech grid
- 64px square grid, slowly translated by `(t × 0.008 × speed) % spacing`.
- Stroke: `oklch(0.7 0.15 145 / 0.05 × intensity)`, 1px.
- 6 pulsing 4×4 square nodes at deterministic positions, alpha modulated by `0.5 + sin(t × 0.0015 + i) × 0.5`, fill `oklch(0.85 0.2 145 / 0.25 × pulse × intensity)`.

### Particles
- 63 particles, radius 0.3–1.7 px.
- Velocity: x random ±0.11; **y biased upward**: `vy = -0.08 - random × 0.18` (growth metaphor — keep this).
- Twinkle: alpha modulated by `0.6 + sin(t × 0.001 × pulse + phase) × 0.4`, base fill `oklch(0.9 0.18 145 / 0.55 × tw × intensity)`.
- Wrap on all four edges with a 10px margin.

### Vignette
- Radial gradient from canvas center, inner radius `min(W,H) × 0.2` (transparent) → outer radius `max(W,H) × 0.75` (`rgba(0,0,0,0.55)`). Fill full canvas.

### Grain
- 180×180 noise tile generated once (`ImageData` with random luminance, alpha 18), repeated as a pattern, drawn at `globalAlpha = 0.035`.

## Motion parameters (locked)
| Param      | Value | Notes |
|------------|------:|-------|
| intensity  | 0.45  | Overall opacity multiplier for green elements |
| speed      | 2.1   | Time multiplier — animation runs fast & energetic |
| particles  | 63    | Particle count |
| grain      | 0.035 | Film grain opacity |
| grid       | true  | Tech grid enabled |

## Design tokens
| Token              | Value         |
|--------------------|---------------|
| Background base    | `#050807`     |
| Green primary      | `#29d17a`     |
| Green hue (OKLCH)  | `145`         |
| Frame fade per tick| `rgba(5,8,7,0.12)` |
| Vignette outer     | `rgba(0,0,0,0.55)` |

## Performance notes
- Single `<canvas>`, no WebGL, no external libs — runs comfortably at 60fps on mid-range hardware.
- DPR is capped at 2 to avoid retina-induced fill-rate hits.
- The grain pattern canvas is built once, reused via `createPattern`.
- If profiling on low-end devices shows issues, the cheapest knobs to dial down (in order) are: `particles` (down to ~30), `grain` (to 0), DPR cap (to 1).
- Pause the animation loop when the page is hidden (`document.visibilityState !== 'visible'`) to save battery on backgrounded tabs — easy win not yet in the prototype.

## Accessibility
- Honor `prefers-reduced-motion: reduce` → render one static frame and stop the RAF loop.
- Canvas should have `aria-hidden="true"` and no role.
- Ensure foreground text contrast on top of the animation stays AA-compliant — the vignette + base black handle this, but verify on the actual site's text colors.

## Reference screenshots
- `reference.png` — frame captured ~1.5s into the animation
- `reference-2.png` — frame captured ~4s in (shows band motion variation)

## Files
- `background.html` — the prototype, fully self-contained. All drawing logic lives in the inline `<script>` block. Lift functions `resize`, `rebuildParticles`, `drawGrid`, `drawAurora`, `drawParticles`, `drawVignette`, `buildGrain`, `drawGrain`, `frame` and the `CFG` object into a module (e.g. `AuroraBackground.ts` / `.js` / a React component wrapping a `<canvas ref>`).

## Suggested integration shape (framework-agnostic)
- Export a single component / mount function that:
  - Creates a `<canvas>`, attaches it to a fixed full-viewport wrapper with `pointer-events: none; z-index: -1`.
  - Starts the RAF loop on mount, cancels it on unmount.
  - Listens to `resize` and `visibilitychange`.
  - Reads `prefers-reduced-motion` once on mount and chooses static vs animated mode accordingly.
- Mount it at the app root, **above** the page router/outlet in the DOM but **below** it visually via z-index.

## Out of scope
- No interactivity (mouse-react, scroll-react) — keep it ambient.
- No theme switching — this is the dark site treatment only.
